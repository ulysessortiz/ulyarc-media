
(()=>{const lang=document.documentElement.lang==='es'?'es':'en';try{localStorage.setItem('ulyarc-language',lang)}catch(e){}
const switcher=document.querySelector('.language-switcher');if(switcher){switcher.addEventListener('click',e=>{const a=e.target.closest('a[lang]');if(a){try{localStorage.setItem('ulyarc-language',a.lang)}catch(x){}}})}
})();
