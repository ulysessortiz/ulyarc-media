(() => {
  const numberWords = {0:'Zero',1:'One',2:'Two',3:'Three',4:'Four',5:'Five',6:'Six',7:'Seven',8:'Eight',9:'Nine',10:'Ten'};
  const setCount = (selector, value) => {
    document.querySelectorAll(selector).forEach(node => {
      const wantsWord = /^[A-Za-z]+$/.test(node.textContent.trim());
      node.textContent = wantsWord && numberWords[value] ? numberWords[value] : String(value);
    });
  };
  fetch('/data/house-records.json', {credentials:'same-origin', cache:'no-cache'})
    .then(response => response.ok ? response.json() : Promise.reject(new Error('House data unavailable')))
    .then(records => {
      if (!Array.isArray(records)) return;
      setCount('[data-house-book-count]', records.filter(record => record.category === 'Book').length);
      setCount('[data-house-web-count]', records.filter(record => record.category === 'Web Property').length);
      setCount('[data-house-total-count]', records.length);
    })
    .catch(() => {});
})();
