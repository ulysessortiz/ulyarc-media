(() => {
  const body = document.body;
  if (!body) return;

  const currentPath = location.pathname.replace(/index\.html$/, '') || '/';
  const currentWorld = body.dataset.world || body.querySelector('main')?.dataset.room || 'home';
  const storageKey = 'ulyarcLivingPropertyV3';
  const ecosystemKey = 'ulyarcLivingArcV2';
  const featureMap = {
    '/publishing/the-third-eye-within/': 'UH-BK-0017',
    '/': 'UH-BK-0017'
  };

  const safeRead = (key) => {
    try {
      const value = JSON.parse(localStorage.getItem(key) || '{}');
      return value && typeof value === 'object' ? value : {};
    } catch (_) { return {}; }
  };
  const safeWrite = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
  };
  const escapeHTML = (value = '') => String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const normalize = (value = '') => String(value).trim();

  const divisionCopy = {
    publishing: {
      label: 'Published form',
      headline: 'The page is where the property acquires its first public body.',
      copy: 'This room can connect a work to edition, format, imprint, distribution, and public destination. A recorded book may be followed here without changing its House record.',
      status: record => record.category === 'Book' ? `${record.status} · ${record.medium || 'Book'}` : 'Publishing relevance requires editorial review.'
    },
    pictures: {
      label: 'Picture lens',
      headline: 'The property enters an aperture, not a promise.',
      copy: 'This room considers visual language, scale, adaptation rights, audience, and production fit.',
      status: () => 'Exploratory lens · rights review required'
    },
    television: {
      label: 'Series lens',
      headline: 'The property is examined for episodic architecture.',
      copy: 'This room considers whether a world can sustain episodes, seasons, recurring characters, or a limited structure.',
      status: () => 'Exploratory lens · rights review required'
    },
    audio: {
      label: 'Sound lens',
      headline: 'The property is listened to before it is reformatted.',
      copy: 'This room considers narration, performance, documentary voice, podcast structure, and sonic atmosphere.',
      status: () => 'Exploratory lens · rights review required'
    },
    music: {
      label: 'Score lens',
      headline: 'The property is tested for rhythm, motif, and emotional architecture.',
      copy: 'This room considers whether music can deepen a world through score, theme, atmosphere, or companion work.',
      status: () => 'Exploratory lens · rights review required'
    },
    interactive: {
      label: 'System lens',
      headline: 'The property is tested for choice, consequence, and return.',
      copy: 'This room considers whether participation can reveal something the original form cannot.',
      status: () => 'Exploratory lens · rights review required'
    }
  };

  async function loadRecords() {
    try {
      const response = await fetch('/data/house-records.json', {credentials: 'same-origin'});
      if (!response.ok) throw new Error('records unavailable');
      return await response.json();
    } catch (_) { return []; }
  }

  function getJourney(state, id) {
    state.properties ||= {};
    state.properties[id] ||= {firstSeen: new Date().toISOString(), paths: [], worlds: []};
    return state.properties[id];
  }

  function rememberProperty(state, record, explicit = false) {
    const journey = getJourney(state, record.id);
    journey.lastSeen = new Date().toISOString();
    journey.paths = Array.from(new Set([...(journey.paths || []), currentPath])).slice(-40);
    journey.worlds = Array.from(new Set([...(journey.worlds || []), currentWorld]));
    if (record.path === currentPath) journey.recordSeen = true;
    if (currentPath.startsWith('/publishing/')) journey.publishingSeen = true;
    if (explicit || record.path === currentPath || (!state.activeId && featureMap[currentPath] === record.id)) state.activeId = record.id;
    state.lastUpdated = new Date().toISOString();
    safeWrite(storageKey, state);
    return journey;
  }

  function stageModel(record, journey) {
    const isBook = record.category === 'Book';
    const isWeb = record.category === 'Web Property';
    return [
      {key:'origin', label:'Origin', title:'Created', copy:`${record.creator || 'Ulysess Ortiz'} is identified as the creative source.`, live:true},
      {key:'form', label:'Public form', title:isWeb ? 'Live' : 'Published', copy:isWeb ? `${record.medium || 'Website'} · ${record.status}` : `${record.medium || 'Book'} · ${record.language || 'Language recorded'}`, live:['Published','Live'].includes(record.status)},
      {key:'record', label:'House spine', title:'Recorded', copy:`${record.id} preserves the public route and inquiry reference.`, live:true},
      {key:'presented', label:'Public route', title:'Presented', copy:record.official ? 'An official public destination is attached to the record.' : 'The public route remains inside the House.', live:Boolean(record.official)},
      {key:'future', label:'Possible future', title:'Other media', copy:'Any screen, sound, music, or interactive path requires separate rights and development review.', live:false, possible:true}
    ];
  }

  function journeySummary(journey) {
    const worlds = journey?.worlds || [];
    if (worlds.includes('house') && worlds.includes('publishing')) return 'Source and House record connected';
    if (worlds.includes('house')) return 'House record encountered';
    if (worlds.some(world => ['pictures','television','audio','music','interactive'].includes(world))) return 'A future-medium lens was opened';
    return 'Property thread opened';
  }

  function injectThreadline(record, journey) {
    const worldline = document.querySelector('.living-worldline');
    if (!worldline || document.querySelector('.property-threadline')) return;
    const progress = Math.min(1, Math.max(.22, (journey?.worlds?.length || 1) / 6));
    const section = document.createElement('div');
    section.className = 'property-threadline';
    section.style.setProperty('--property-progress', String(progress));
    section.setAttribute('aria-label', 'Active creative property thread');
    section.innerHTML = `
      <div class="property-thread-inner">
        <div class="property-thread-identity"><span aria-hidden="true" class="property-thread-mark"></span><div><small>Property thread · ${escapeHTML(record.id)}</small><strong>${escapeHTML(record.title)}</strong></div></div>
        <div class="property-thread-state"><small>Headquarters memory</small><strong>${escapeHTML(journeySummary(journey))}</strong></div>
        <div class="property-thread-actions"><a href="${escapeHTML(record.path)}">Open record</a><a href="/studio/">Follow through studio</a><button data-clear-property type="button">Release thread</button></div>
      </div>`;
    worldline.insertAdjacentElement('afterend', section);
    section.querySelector('[data-clear-property]')?.addEventListener('click', () => {
      const state = safeRead(storageKey);
      delete state.activeId;
      safeWrite(storageKey, state);
      section.remove();
      document.documentElement.removeAttribute('data-active-property');
    });
  }

  function enhanceHome(record, journey) {
    const signal = document.querySelector('[data-property-signal]');
    if (!signal) return;
    const stages = stageModel(record, journey);
    signal.querySelector('[data-signal-kicker]').textContent = journey?.paths?.length > 1 ? 'RETURNING PROPERTY SIGNAL' : 'CURRENT STUDIO SIGNAL';
    signal.querySelector('[data-signal-title]').innerHTML = `${escapeHTML(record.title)}<br><em>has a visible spine.</em>`;
    signal.querySelector('[data-signal-copy]').textContent = `${record.creator} is the source. ${record.status} is the public state. ${record.id} is the House reference. Other media remain possible pathways, not announced productions.`;
    signal.querySelector('[data-signal-meta]').innerHTML = [record.id, record.category, record.status, record.language].filter(Boolean).map(item => `<span>${escapeHTML(item)}</span>`).join('');
    const recordLink = signal.querySelector('[data-signal-record]');
    recordLink.href = record.path;
    const officialLink = signal.querySelector('[data-signal-official]');
    if (record.official) { officialLink.href = record.official; officialLink.hidden = false; } else officialLink.hidden = true;
    signal.querySelectorAll('[data-orbit-stage]').forEach((node, index) => node.classList.toggle('is-live', Boolean(stages[index]?.live)));
  }

  function enhanceStudio(record, journey) {
    const anatomy = document.querySelector('[data-property-anatomy]');
    if (!anatomy) return;
    const stages = stageModel(record, journey);
    anatomy.querySelector('[data-anatomy-title]').textContent = record.title;
    anatomy.querySelector('[data-anatomy-summary]').textContent = `${record.id} is the factual spine. The studio can examine other media without turning possibility into an announcement.`;
    anatomy.querySelector('[data-anatomy-track]').innerHTML = stages.map(stage => `
      <article class="property-stage${stage.live ? ' is-live' : ''}${stage.possible ? ' is-possible' : ''}">
        <span>${escapeHTML(stage.label)}</span><h3>${escapeHTML(stage.title)}</h3><p>${escapeHTML(stage.copy)}</p>
      </article>`).join('');
    anatomy.querySelector('[data-anatomy-record]').href = record.path;
    anatomy.querySelector('[data-anatomy-foot]').innerHTML = `<strong>${escapeHTML(journeySummary(journey))}</strong> · ${journey?.worlds?.length || 1} studio room${(journey?.worlds?.length || 1) === 1 ? '' : 's'} touched`;
  }

  function injectRecordPathway(record, journey) {
    const layout = document.querySelector('.record-layout');
    if (!layout || document.querySelector('.record-property-pathway')) return;
    const stages = stageModel(record, journey);
    const section = document.createElement('section');
    section.className = 'record-property-pathway';
    section.setAttribute('aria-label', 'Creative property pathway');
    section.innerHTML = `
      <div class="record-pathway-head"><div><small>Living property system</small><strong>This record is the property’s factual spine.</strong></div><a href="/studio/">Follow ${escapeHTML(record.id)} through the studio ↗</a></div>
      <div class="record-pathway-steps">${stages.slice(0,4).map(stage => `<span class="${stage.live ? 'is-live' : ''}${stage.possible ? ' is-possible' : ''}">${escapeHTML(stage.label)} · ${escapeHTML(stage.title)}</span>`).join('')}</div>`;
    layout.insertAdjacentElement('beforebegin', section);

    const actions = document.querySelector('.record-actions');
    if (actions && !actions.querySelector('[data-follow-property]')) {
      const link = document.createElement('a');
      link.className = 'button secondary';
      link.dataset.followProperty = record.id;
      link.href = '/studio/';
      link.textContent = 'Follow through the studio';
      actions.append(link);
    }
  }

  function injectDivisionLens(record, journey) {
    const config = divisionCopy[currentWorld];
    if (!config || document.querySelector('.property-lens')) return;
    const main = document.querySelector('main');
    const exit = main?.querySelector('.division-exit');
    const anchor = exit || main?.lastElementChild;
    if (!main || !anchor) return;
    const lens = document.createElement('section');
    lens.className = 'property-lens page-width';
    lens.setAttribute('aria-label', `Property lens for ${record.title}`);
    lens.innerHTML = `
      <div class="property-lens-grid">
        <div><p class="eyebrow">${escapeHTML(config.label)} · ${escapeHTML(record.id)}</p><h2>${escapeHTML(config.headline)}</h2><p><strong>${escapeHTML(record.title)}</strong> is the active property thread. ${escapeHTML(config.copy)}</p><div class="actions"><a class="button glass" href="${escapeHTML(record.path)}">Open House record</a><a class="text-link" href="/business/rights-and-licensing/">Professional rights route ↗</a></div><p class="property-lens-note">Pathway view only. No adaptation or production is announced here.</p></div>
        <div class="property-lens-state"><div><span>Property</span><strong>${escapeHTML(record.title)}</strong></div><div><span>Record</span><strong>${escapeHTML(record.id)}</strong></div><div><span>Public state</span><strong>${escapeHTML(record.status)}</strong></div><div><span>This room</span><strong>${escapeHTML(config.status(record))}</strong></div><div><span>Thread</span><strong>${escapeHTML(journeySummary(journey))}</strong></div></div>
      </div>`;
    anchor.insertAdjacentElement('beforebegin', lens);
  }

  function awakenCentralArc() {
    const state = safeRead(ecosystemKey);
    const worlds = state.visitedWorlds || [];
    const map = {
      PUBLISHING: ['publishing','work'], PICTURES: ['pictures'], TELEVISION: ['television'],
      AUDIO: ['audio'], MUSIC: ['music'], INTERACTIVE: ['interactive']
    };
    document.querySelectorAll('.arc-orbit .orbit-node').forEach(node => {
      const keys = map[normalize(node.textContent).toUpperCase()] || [];
      node.classList.toggle('is-awake', keys.some(key => worlds.includes(key)));
    });
  }

  function bindPropertyLinks(recordsByPath, recordsById, state) {
    document.addEventListener('click', event => {
      const link = event.target.closest('a[href]');
      if (!link) return;
      let url;
      try { url = new URL(link.href, location.href); } catch (_) { return; }
      if (url.origin !== location.origin) return;
      const path = url.pathname.replace(/index\.html$/, '') || '/';
      const record = recordsByPath.get(path) || recordsById.get(link.dataset.followProperty || '');
      if (!record) return;
      state.activeId = record.id;
      const journey = getJourney(state, record.id);
      journey.lastSeen = new Date().toISOString();
      safeWrite(storageKey, state);
    }, {capture:true});
  }

  async function init() {
    const records = await loadRecords();
    if (!records.length) return;
    const recordsByPath = new Map(records.map(record => [record.path, record]));
    const recordsById = new Map(records.map(record => [record.id, record]));
    const directRecord = recordsByPath.get(currentPath);
    const mappedRecord = recordsById.get(featureMap[currentPath]);
    const state = safeRead(storageKey);
    const storedRecord = recordsById.get(state.activeId);
    const record = directRecord || (currentPath === '/' ? (storedRecord || mappedRecord) : (mappedRecord || storedRecord)) || records.find(item => item.featured) || records[0];
    const explicit = Boolean(directRecord || (mappedRecord && currentPath !== '/'));
    const journey = rememberProperty(state, record, explicit);

    document.documentElement.dataset.activeProperty = record.id;
    document.documentElement.style.setProperty('--property-progress', String(Math.min(1, Math.max(.22, (journey.worlds?.length || 1) / 6))));

    if (state.activeId || directRecord || explicit) injectThreadline(record, journey);
    enhanceHome(record, journey);
    enhanceStudio(record, journey);
    injectRecordPathway(directRecord, journey);
    injectDivisionLens(record, journey);
    awakenCentralArc();
    bindPropertyLinks(recordsByPath, recordsById, state);

    const arrival = document.querySelector('[data-arrival-message]');
    const kicker = document.querySelector('[data-arrival-kicker]');
    if (currentPath === '/' && arrival && state.activeId) {
      kicker.textContent = 'PROPERTY SIGNAL RETURNED';
      arrival.textContent = `The headquarters remembers ${record.title}. Its House record and studio pathways remain connected.`;
    }
  }

  init();
})();
