(() => {
  const body = document.body;
  if (!body) return;

  const storageKey = 'ulyarcLivingArcV2';
  const isEs = document.documentElement.lang === 'es';
  const currentPath = location.pathname.replace(/index\.html$/, '') || '/';
  const currentWorld = body.dataset.world || 'home';
  const roomNames = isEs ? {
    home:'Arco Central · Sede', work:'Campo de Descubrimiento · Obras', studio:'Cámara de Convergencia · Estudio', publishing:'Bóveda de Papel · Publicaciones', pictures:'Sala de Apertura · Cine', television:'Sala de Señal · Televisión', audio:'Sala de Eco · Audio', music:'Sala de Pulso · Música', interactive:'Cuadrícula de Elección · Interactivo', house:'Bóveda de Registros · La Casa', company:'Órbita del Fundador · Marca', business:'Canal Discreto · Negocios', legal:'Archivo de Límites · Legal', map:'Atlas de Rutas · Mapa del Sitio'
  } : {
    home: 'Central Arc · Headquarters', work: 'Discovery Field · Work', studio: 'Convergence Chamber · Studio', publishing: 'Paper Vault · Publishing', pictures: 'Aperture Room · Pictures', television: 'Signal Room · Television', audio: 'Echo Room · Audio', music: 'Pulse Room · Music', interactive: 'Choice Grid · Interactive', house: 'Record Vault · The House', company: 'Founder Orbit · Brand', business: 'Quiet Channel · Business', legal: 'Boundary Archive · Legal', map: 'Route Atlas · Site Map'
  };

  const safeRead = () => {
    try {
      const parsed = JSON.parse(localStorage.getItem(storageKey) || '{}');
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (_) {
      return {};
    }
  };
  const safeWrite = value => {
    try { localStorage.setItem(storageKey, JSON.stringify(value)); } catch (_) {}
  };

  const previous = safeRead();
  const previousPath = previous.lastPath && previous.lastPath !== currentPath ? previous.lastPath : '';
  const visitedPaths = Array.from(new Set([...(previous.visitedPaths || []), currentPath])).slice(-60);
  const visitedWorlds = Array.from(new Set([...(previous.visitedWorlds || []), currentWorld]));
  const state = {
    firstSeen: previous.firstSeen || new Date().toISOString(),
    lastSeen: new Date().toISOString(),
    lastPath: currentPath,
    lastWorld: currentWorld,
    pageCrossings: Number(previous.pageCrossings || 0) + 1,
    visitedPaths,
    visitedWorlds
  };
  safeWrite(state);

  body.classList.add(previous.firstSeen ? 'returning-world' : 'first-world');
  body.dataset.crossings = String(state.pageCrossings);

  const hour = new Date().getHours();
  const daypart = hour < 6 ? 'deep-night' : hour < 12 ? 'morning' : hour < 18 ? 'day' : 'afterglow';
  document.documentElement.dataset.daypart = daypart;

  document.querySelectorAll('[data-current-room]').forEach(node => {
    node.textContent = roomNames[currentWorld] || roomNames.home;
  });
  document.querySelectorAll('[data-room-memory]').forEach(node => {
    const count = visitedWorlds.length;
    node.textContent = isEs ? `${count} sala${count===1?'':'s'} recordada${count===1?'':'s'}` : `${count} room${count === 1 ? '' : 's'} remembered`;
  });

  document.querySelectorAll('[data-world-link]').forEach(link => {
    const world = link.dataset.worldLink;
    if (visitedWorlds.includes(world)) link.classList.add('is-visited');
    if (world === currentWorld || (currentWorld === 'publishing' && world === 'studio') || ['pictures','television','audio','music','interactive'].includes(currentWorld) && world === 'studio') {
      link.setAttribute('aria-current', 'page');
    }
  });

  document.querySelectorAll('a[href]').forEach(link => {
    let path;
    try {
      const url = new URL(link.href, location.href);
      if (url.origin !== location.origin) return;
      path = url.pathname.replace(/index\.html$/, '') || '/';
    } catch (_) { return; }
    if (visitedPaths.includes(path)) link.classList.add('is-visited');
  });

  const arrivalMessage = document.querySelector('[data-arrival-message]');
  const arrivalKicker = document.querySelector('[data-arrival-kicker]');
  const returnLink = document.querySelector('[data-return-route]');
  if (arrivalMessage) {
    const count = visitedWorlds.length;
    arrivalMessage.textContent = previous.firstSeen
      ? (isEs ? `La sede recuerda ${count} sala${count===1?'':'s'} de tu recorrido.` : `The headquarters remembers ${count} room${count === 1 ? '' : 's'} from your trail.`)
      : (isEs ? 'El Arco central está abierto. Elige una señal y el mundo se reorganizará a su alrededor.' : 'The central Arc is open. Choose a signal and the world will rearrange around it.');
  }
  if (arrivalKicker) arrivalKicker.textContent = previous.firstSeen ? (isEs ? 'SEÑAL DE REGRESO RECIBIDA' : 'RETURN SIGNAL RECEIVED') : (isEs ? 'SEDE DESPIERTA' : 'HEADQUARTERS AWAKE');
  if (returnLink && previousPath) {
    returnLink.href = isEs && !previousPath.startsWith('/es/') ? (previousPath==='/'?'/es/':'/es'+previousPath) : previousPath;
    returnLink.hidden = false;
  }

  document.querySelectorAll('[data-clear-world-memory]').forEach(button => {
    button.addEventListener('click', () => {
      try { localStorage.removeItem(storageKey); } catch (_) {}
      location.reload();
    });
  });

  const finePointer = matchMedia('(pointer:fine)').matches;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (finePointer && !reduced) {
    let frame = 0;
    addEventListener('pointermove', event => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        document.documentElement.style.setProperty('--world-x', `${(event.clientX / innerWidth * 100).toFixed(1)}%`);
        document.documentElement.style.setProperty('--world-y', `${(event.clientY / innerHeight * 100).toFixed(1)}%`);
        frame = 0;
      });
    }, {passive: true});
  }
})();
