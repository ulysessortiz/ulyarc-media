# A Story Stays custom-domain link repair — ULYARC MEDIA

Surgical scope: replace only `https://astorystays.netlify.app/` with `https://astorystays.com/`. Existing paths, query strings, layout, content, scripts, and other links were preserved.

Files changed: 10

- `index.html` — 1 replacement(s)
- `originals/index.html` — 1 replacement(s)
- `data/house-records.json` — 1 replacement(s)
- `assets/js/house.js` — 1 replacement(s)
- `es/index.html` — 1 replacement(s)
- `es/originals/index.html` — 1 replacement(s)
- `es/interactive/index.html` — 1 replacement(s)
- `es/house/web-properties/a-story-stays/index.html` — 2 replacement(s)
- `interactive/index.html` — 1 replacement(s)
- `house/web-properties/a-story-stays/index.html` — 2 replacement(s)
